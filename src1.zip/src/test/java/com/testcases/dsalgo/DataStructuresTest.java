package com.testcases.dsalgo;

public class DataStructuresTest {

}
