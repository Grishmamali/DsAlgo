package com.pageobject.dsalgo;

public class QueuePage {

}
